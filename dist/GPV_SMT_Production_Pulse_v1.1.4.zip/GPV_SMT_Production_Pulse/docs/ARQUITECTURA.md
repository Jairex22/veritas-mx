# Arquitectura — GPV SMT Production Pulse v1.1.4

## Novedades v1.1: recolector automático

```
                 ┌──────────── proceso único (py app.py --live) ────────────┐
FactoryLogix ◄── │ collector.py  (1 hilo, lock de SO, 1 GET / 300 s)        │
   OData         │      │ upsert sin duplicados + revisiones                │
                 │      ▼                                                    │
                 │ SQLite: production_records · record_revisions ·           │
                 │         collector_runs · application_settings             │
                 │      ▲                                                    │
                 │ live_metrics.py / pulse_service.py (solo lectura local)   │
                 │      ▲                                                    │
                 │ app.py  /api/monitor  /api/query (local)  /api/compare-local
                 └──────┼────────────────────────────────────────────────────┘
                        │ fetch cada 30 s (JSON local, sin recargar la página)
                 navegadores (N usuarios → 0 consultas OData adicionales)
```

**Ciclo del recolector** (`collector.Collector.tick`):

1. *Validación* (al iniciar, tras un HTTP 400/404 o cada `probe_recheck_hours` si estaba bloqueado):
   `$metadata` → mapeo (confirmado / `config.json` / auto-detectado y señalado) → sondas `$top=1`.
   Si `$top` o el filtro de fecha no están comprobados → **bloqueado**, no se envía nada.
2. *Recolección*: `GET ProductivityOverTime?$select=…&$filter=<fecha> ge A and <fecha> lt B&$orderby=<fecha> asc&$top=50`
   (`$select`/`$orderby` solo si están comprobados). Ventana `A = min(cursor, ahora − lookback)`, `B = ahora`.
3. *Página completa* con orden ascendente comprobado → el siguiente ciclo continúa desde el registro
   más reciente recibido (**sincronización por cursor**: sigue siendo 1 consulta por ciclo; nunca se
   sigue `nextLink`). Sin orden comprobado → se registra un hueco visible.
4. *Persistencia*: `production_records` (1 fila por clave de entidad, último contenido),
   `record_revisions` (cada lectura nueva o modificada: historial de lecturas), `collector_runs`
   (bitácora de cada ciclo con ventana, HTTP, ms, recibidos/nuevos/actualizados/sin cambio y una
   instantánea de métricas para calcular el incremento entre lecturas).
5. *Errores*: 401/403/5xx/timeout/desconexión → se conservan los datos, advertencia en el monitor y
   espera `300 · 2ⁿ` s (máx. `max_backoff_seconds`; errores de autenticación empiezan en 600 s).
   El circuit breaker del cliente es una segunda barrera. Las sondas interrumpidas por caída del
   servidor no se guardan como evidencia y no se repiten hasta el siguiente intento programado.

**Instancia única**: `SingleInstanceLock` (`msvcrt.locking` en Windows, `fcntl.flock` en otros) sobre
`data/collector_<modo>.lock`; una segunda instancia termina antes de abrir el puerto o consultar.

**Semántica de la cantidad** (`live_metrics`): `interval` (se suma), `cumulative` (diferencia entre
lecturas consecutivas por línea+estación, reinicio si baja, sin lectura base = desconocido) o
`undetermined` (no se calculan unidades). Con `auto` se detecta por patrón y se rotula como
pendiente de confirmar.

**Tiempos**: *hora de consulta* (`collector_runs.started_at`, `last_success_at`) y *hora de producción*
(campo de fecha de cada registro) se guardan y muestran por separado; el monitor muestra la
antigüedad del registro más reciente y la diferencia con la última consulta. Durante la
sincronización, las horas posteriores al cursor se marcan como incompletas y no entran en la
tendencia.

**Modo recolector en la interfaz**: Monitor, Consulta histórica, Tendencias y Reportes leen solo
SQLite (`PulseService.collector_mode`); los filtros por línea/estación/turno se aplican localmente.
Las únicas solicitudes adicionales son las acciones explícitas de administrador en "Estado de
conexión" (limitadas en frecuencia).

## Decisiones principales

| Decisión | Motivo |
|---|---|
| Solo biblioteca estándar de Python (`http.server`, `urllib`, `sqlite3`, `xml.etree`, `zipfile`) | Cero dependencias obligatorias: funciona descomprimiendo el ZIP en una cuenta estándar, sin pip, sin internet, sin bibliotecas obsoletas a futuro. Flask no aporta lo suficiente para este alcance (pocas rutas JSON). |
| XLSX generado con `zipfile` + SpreadsheetML | Excel nativo sin `openpyxl`. Validado abriendo en LibreOffice. |
| PDF mediante vista de impresión del navegador | Evita bibliotecas PDF pesadas; el navegador produce PDF fiel con gráficas SVG. |
| Autenticación como el propio usuario (SSPI, sin instalar) | El servidor exige autenticación de Windows en la entidad. La app se identifica con la sesión del operador mediante `ctypes` → `Secur32.dll` (Negotiate/NTLM), igual que el navegador. No guarda contraseñas ni requiere pip/admin. Si la cuenta no tiene permiso, el 401 persiste (lo resuelve TI). El servidor de GPV usa **HTTP Basic**: con las credenciales que escribe el operador, `AuthHttpTransport` envía `Authorization: Basic` (y, si el servidor pidiera Negotiate/NTLM en Windows, recurre a SSPI con esa identidad). Contraseña solo en memoria, nunca persistida ni registrada. `auth_mode`: `auto`, `none`. |
| DEMO como *transporte simulado* | El modo DEMO ejecuta el **mismo** cliente OData, caché, sondas y análisis que producción; solo cambia la capa de red. |
| Base SQLite separada para DEMO | Imposible mezclar datos simulados y reales (la base registra su modo y rechaza el otro). |

## Módulos

```
Navegador (HTML/CSS/JS nativo, SVG)
   │  JSON (solo 127.0.0.1, cookie de sesión HttpOnly, cabecera anti-CSRF)
   ▼
app.py ─────────── rutas HTTP, cabeceras de seguridad, validación de Host/Origin
   ▼
pulse_service.py ─ flujo de consulta, reglas de bloqueo, mapeo, diagnóstico, reportes
   ├── security.py ........ validación de entradas y literales OData
   ├── database.py ........ caché / historial / reportes / ajustes (SQLite WAL)
   ├── analytics.py ....... métricas solo con campos confirmados
   ├── report_generator.py  CSV, XLSX, snapshot para PDF
   ├── metadata_inspector.py  EDMX → esquema validado + sugerencias de campos
   ├── capability_probe.py  sondas $top=1 explícitas
   └── odata_client.py .... ÚNICO punto de salida de red
            ├── UrllibTransport (anónimo) / SspiHttpTransport (sesión Windows, sspi_auth.py)
            └── DemoTransport (demo_source.py)       (simulador)
settings.py ─ config.json validado (rangos, tipos, entidad única, localhost)
timeutil.py ─ zona horaria de planta, parseo de fechas OData V2/V3/V4
```

Respecto a la estructura sugerida se añadieron `pulse_service.py` (separa reglas de negocio de
HTTP), `capability_probe.py` (las pruebas de compatibilidad son un concepto propio con evidencia
persistida), `demo_source.py`, `settings.py` y `timeutil.py`, y las pantallas JS se dividieron
por página (`production.js`, `dashboard.js`, `diagnostics.js`, `reports.js`) además de
`app.js` (núcleo) y `charts.js`.

## Tres niveles de evidencia

1. **Declarado**: la propiedad existe en `$metadata` (`metadata_inspector`).
2. **Anunciado**: anotaciones `Org.OData.Capabilities.V1.*` lo indican (solo informativo).
3. **Comprobado**: una sonda `$top=1` respondió 200 **y** el resultado es coherente (p. ej. los
   registros devueltos están dentro del rango; si no, el filtro se marca *falló* porque el
   servidor lo ignoró).

Las sondas se ligan al hash del esquema + mapeo; si cualquiera cambia, dejan de valer.

## Política de consultas (aplicada en código, con pruebas)

| Regla | Dónde |
|---|---|
| Solo `GET` a `$metadata` y `ProductivityOverTime` | `security.ensure_allowed_resource`, `ODataClient.build_relative_url` |
| `$top` obligatorio y ≤ `MAX_RECORDS` | `build_relative_url` |
| Una solicitud activa por proceso; la segunda se **rechaza** (no se encola) | `RequestGate` |
| Espaciado mínimo, presupuesto por sesión y global por hora | `RequestGate` |
| Circuit breaker (3 fallas → 300 s; `Retry-After` en 429) | `CircuitBreaker` |
| Sin reintentos, sin redirecciones, sin seguir `nextLink` | `ODataClient`, `_NoRedirect` |
| Respuesta máxima `MAX_RESPONSE_BYTES`, plazo total `REQUEST_TIMEOUT_SECONDS` | `_read_bounded` |
| Consulta bloqueada si `$top` o filtro de fecha no están comprobados | `PulseService.readiness` |
| Nunca sustituir una consulta filtrada fallida por una sin filtros | `run_query` devuelve el error |
| `$select`/`$orderby` solo si se comprobaron | `PulseService.build_spec` |
| Caché compartida entre usuarios locales (TTL 300 s) | `odata_cache` + firma normalizada |
| Sin polling; auto-refresco desactivado y rechazado por el backend | `AUTO_REFRESH_ENABLED=false` |
| Navegador no puede enviar consultas OData arbitrarias | La API acepta solo fechas/valores validados |

Consulta típica generada:

```
ProductivityOverTime?$select=<clave>,<fecha>,<cantidad>,<línea>...
  &$filter=<fecha> ge 2026-11-02T06:00:00Z and <fecha> lt 2026-11-04T06:00:00Z and <línea> eq 'SMT-L01'
  &$orderby=<fecha> desc&$top=50
```

## Base de datos (`data/production_pulse.db`)

* `odata_cache`: id de conjunto, firma, parámetros, URL relativa, fecha de consulta y expiración,
  registros (JSON), cantidad, `more_available` (truncado), estado de validación, hash de respuesta, hash de esquema. Máximo 3 instantáneas por firma.
* `query_history`: fecha, tipo (query/metadata/probe), consulta, ms, registros, HTTP, resultado,
  estado de caché (hit/miss/blocked), detalle técnico.
* `saved_reports`: id, generación, periodo, filtros, fuente, fecha de extracción, caché, snapshot.
* `application_settings`: mapeo confirmado, resultados de sondas, límites efectivos.

Retención: caché 7 días, historial 30 días, reportes 90 días, tamaño máximo 200 MB (se eliminan
las instantáneas más antiguas y se compacta). Sin credenciales en ninguna tabla.

## Seguridad

* Escucha en `127.0.0.1`; otro host requiere `allow_non_localhost` explícito.
* Validación de `Host` (anti DNS-rebinding), `Origin` y cabecera `X-Pulse-Request` en POST; cookie
  `HttpOnly; SameSite=Strict`; cuerpo JSON ≤ 16 KB.
* CSP estricta (`script-src 'self'`, sin scripts ni estilos en línea), `nosniff`, `DENY` frames.
* Frontend construye el DOM con `textContent` (todo dato se escapa).
* Valores de filtro con lista blanca de caracteres y comillas OData duplicadas; nombres de campo
  validados contra metadata; operadores en lista blanca.
* XML de metadata: rechazo de DTD/ENTITY, tamaño máximo.
* Logs rotativos con filtro que oculta Authorization/Cookie/contraseñas.
* Exportaciones protegidas contra inyección de fórmulas.

## Zona horaria

Las fechas del filtro se interpretan como días completos en hora local de la planta (reglas del
sistema operativo, o `analytics.plant_timezone`). Para `Edm.DateTimeOffset` se envía UTC; para
`Edm.DateTime` (sin zona) se envía hora local: **pendiente de validar en GPV**.

## Extensión futura

* Nuevos roles de campo: agregar a `settings.FIELD_ROLES`, `metadata_inspector._ROLE_HINTS`,
  `role_type_compatible` y una sonda en `capability_probe`.
* Nuevas métricas: `analytics.analyze` (siempre con estado verified/partial/unavailable).
* Otras áreas además de SMT: la entidad sigue siendo la única autorizada; se añadirían filtros.
